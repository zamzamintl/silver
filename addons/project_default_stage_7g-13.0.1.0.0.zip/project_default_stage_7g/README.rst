Project Default Stage
=====================

This module offers default task stages for projects. If enabled while creating a stage and a project,
the module creates all the default stages when on project creation.

Support
-------
Please visit https://sevengates.co or email to support@sevengates.co

LICENSE
-------
OPL-1: `License File <LICENSE>`_

Credit
-------
`Seven Gates <https://sevengates.co>`_
