# -*- coding: utf-8 -*-
from . import base_model
from . import deleted_records
from . import res_config_settings
