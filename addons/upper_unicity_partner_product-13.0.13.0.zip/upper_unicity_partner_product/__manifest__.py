# -*- coding: utf-8 -*-


{
    'name': 'Upper case Customers/Suppliers/Products/Entrepôts & Unicity',
    'version': '13.0',
    'category': 'Human Resources/Employees',
    'sequence': 200,
    'summary': 'Transformation min/maj, unicité',
    'description': """
    Module complémentaire    """,
    'author': 'Odoo Tips',
    "website" : "https://www.facebook.com/OdooTips/",
    'depends': ['base','sale','purchase','stock'],
    'images': ['images/main_screenshot.png'],
    'data': [ ],
    'installable': True,
    'auto_install': False,
    'application': True,
}
