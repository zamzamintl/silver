# -*- coding: utf-8 -*-
from . import delete_records_upto
