# -*- coding: utf-8 -*-

from . import partner
from . import product
from . import warehouse
