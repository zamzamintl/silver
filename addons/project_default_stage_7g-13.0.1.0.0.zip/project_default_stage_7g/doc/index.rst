Project Default Stage
======================

This module offers default task stages for the project.

Steps
-----
1. Install module
2. Go to ``Project > Configuration > Stages`` menu.
3. You can choose as default in releated stages.
4. If enabled in the project it creates all the default task stages one by one for the project.
5. It can be choosen for one time as default in Project Configuration. Selected stages as default are created automatically while creating a project.
6. Your project will be created with your default stages.

Support
-------
Please visit https://sevengates.co or email to support@sevengates.co
